/*
	In the name of GOD
	This library has produced by Hadikh73
        #include <m2s.h>
	This is Miladi to Shamsi Converter
*/

#ifndef _M2S_INCLUDED_
#define _M2S_INCLUDED_

#pragma used+

int m2s(int ym,int mm,int dm,int *ys,int *ms,int *ds);

#pragma used-
#pragma library m2s.lib

#endif

