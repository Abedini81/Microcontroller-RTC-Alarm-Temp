/*******************************************************
Chip type               : ATmega32A
Program type            : Application
AVR Core Clock frequency: 8.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*******************************************************/

#include <mega32a.h>

// I2C Bus functions
#include <i2c.h>

// DS1307 Real Time Clock functions
#include <ds1307.h>

// Alphanumeric LCD functions
#include <alcd.h>

#include <delay.h>
#include <math.h>
#include <stdio.h>
#include <m2s.h>

// Declare your global variables here
float Temp;
char lcd_buff[16];
unsigned char Hour, Minute, Second = 0;
eeprom unsigned char Year_century;
unsigned char Year, Month, Day, Weekday = 0;
 int sYear = 0;
 int sMonth, sDay = 0;
unsigned char menu_selector = 0;
unsigned int A_Year = 0;
unsigned char A_Month=0, A_Day = 0;
unsigned char A_Hour=0, A_Minute=0;
unsigned char alarm_selector = 0;                 
unsigned char alarm = 0;
eeprom  unsigned char E_alarm = 0;
eeprom  unsigned int  AE_Year = 0;
eeprom  unsigned char AE_Month=0, AE_Day = 0;
eeprom  unsigned char AE_Hour=0, AE_Minute=0;

flash char degreeSymbol[8] = 
{
0b000110,
0b001001,
0b001001,
0b000110,
0b000000,
0b000000,
0b000000,
0b000000
};

// Declare your global functions
void time_date_functions();
int isLeapYear(int _year, int _type);
void main_loop();
void up_sw();
void menu_sw();
void down_sw();
void showMenu();
void A_up_sw();
void A_menu_sw();
void A_down_sw();
void alarmMenu();
void read_eeprom();

void define_char(char flash *pc, char char_code);
// Declare your global variables here

// Voltage Reference: Int., cap. on AREF
#define ADC_VREF_TYPE ((1<<REFS1) | (1<<REFS0) | (1<<ADLAR))


// Read the 8 most significant bits
// of the AD conversion result
unsigned char read_adc(unsigned char adc_input)
{
ADMUX=adc_input | ADC_VREF_TYPE;
// Delay needed for the stabilization of the ADC input voltage
delay_us(10);
// Start the AD conversion
ADCSRA|=(1<<ADSC);
// Wait for the AD conversion to complete
while ((ADCSRA & (1<<ADIF))==0);
ADCSRA|=(1<<ADIF);
return ADCH;
}

void main(void)
{
// Declare your local variables here

// Input/Output Ports initialization
// Port A initialization
// Function: Bit7=Out Bit6=Out Bit5=Out Bit4=Out Bit3=Out Bit2=In Bit1=In Bit0=In 
DDRA=(1<<DDA7) | (1<<DDA6) | (1<<DDA5) | (1<<DDA4) | (1<<DDA3) | (0<<DDA2) | (0<<DDA1) | (0<<DDA0);
// State: Bit7=0 Bit6=0 Bit5=0 Bit4=0 Bit3=0 Bit2=P Bit1=P Bit0=P 
PORTA=(0<<PORTA7) | (0<<PORTA6) | (0<<PORTA5) | (0<<PORTA4) | (0<<PORTA3) | (1<<PORTA2) | (1<<PORTA1) | (1<<PORTA0);

// Port B initialization
// Function: Bit7=Out Bit6=Out Bit5=Out Bit4=Out Bit3=Out Bit2=Out Bit1=Out Bit0=Out 
DDRB=(1<<DDB7) | (1<<DDB6) | (1<<DDB5) | (1<<DDB4) | (1<<DDB3) | (1<<DDB2) | (1<<DDB1) | (1<<DDB0);
// State: Bit7=0 Bit6=0 Bit5=0 Bit4=0 Bit3=0 Bit2=0 Bit1=0 Bit0=0 
PORTB=(0<<PORTB7) | (0<<PORTB6) | (0<<PORTB5) | (0<<PORTB4) | (0<<PORTB3) | (0<<PORTB2) | (0<<PORTB1) | (0<<PORTB0);

// Port C initialization
// Function: Bit7=Out Bit6=Out Bit5=Out Bit4=Out Bit3=Out Bit2=Out Bit1=Out Bit0=Out 
DDRC=(1<<DDC7) | (1<<DDC6) | (1<<DDC5) | (1<<DDC4) | (1<<DDC3) | (1<<DDC2) | (1<<DDC1) | (1<<DDC0);
// State: Bit7=0 Bit6=0 Bit5=0 Bit4=0 Bit3=0 Bit2=0 Bit1=0 Bit0=0 
PORTC=(0<<PORTC7) | (0<<PORTC6) | (0<<PORTC5) | (0<<PORTC4) | (0<<PORTC3) | (0<<PORTC2) | (0<<PORTC1) | (0<<PORTC0);

// Port D initialization
// Function: Bit7=Out Bit6=Out Bit5=Out Bit4=Out Bit3=Out Bit2=Out Bit1=Out Bit0=Out 
DDRD=(1<<DDD7) | (1<<DDD6) | (1<<DDD5) | (1<<DDD4) | (1<<DDD3) | (1<<DDD2) | (1<<DDD1) | (1<<DDD0);
// State: Bit7=0 Bit6=0 Bit5=0 Bit4=0 Bit3=0 Bit2=0 Bit1=0 Bit0=0 
PORTD=(0<<PORTD7) | (0<<PORTD6) | (0<<PORTD5) | (0<<PORTD4) | (0<<PORTD3) | (0<<PORTD2) | (0<<PORTD1) | (0<<PORTD0);

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: Timer 0 Stopped
// Mode: Normal top=0xFF
// OC0 output: Disconnected
TCCR0=(0<<WGM00) | (0<<COM01) | (0<<COM00) | (0<<WGM01) | (0<<CS02) | (0<<CS01) | (0<<CS00);
TCNT0=0xD8;
OCR0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: Timer1 Stopped
// Mode: Normal top=0xFFFF
// OC1A output: Disconnected
// OC1B output: Disconnected
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
TCCR1A=(0<<COM1A1) | (0<<COM1A0) | (0<<COM1B1) | (0<<COM1B0) | (0<<WGM11) | (0<<WGM10);
TCCR1B=(0<<ICNC1) | (0<<ICES1) | (0<<WGM13) | (0<<WGM12) | (0<<CS12) | (0<<CS11) | (0<<CS10);
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer2 Stopped
// Mode: Normal top=0xFF
// OC2 output: Disconnected
ASSR=0<<AS2;
TCCR2=(0<<PWM2) | (0<<COM21) | (0<<COM20) | (0<<CTC2) | (0<<CS22) | (0<<CS21) | (0<<CS20);
TCNT2=0x00;
OCR2=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=(0<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (0<<OCIE0) | (0<<TOIE0);

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
// INT2: Off
MCUCR=(0<<ISC11) | (0<<ISC10) | (0<<ISC01) | (0<<ISC00);
MCUCSR=(0<<ISC2);

// USART initialization
// USART disabled
UCSRB=(0<<RXCIE) | (0<<TXCIE) | (0<<UDRIE) | (0<<RXEN) | (0<<TXEN) | (0<<UCSZ2) | (0<<RXB8) | (0<<TXB8);

// Analog Comparator initialization
// Analog Comparator: Off
// The Analog Comparator's positive input is
// connected to the AIN0 pin
// The Analog Comparator's negative input is
// connected to the AIN1 pin
ACSR=(1<<ACD) | (0<<ACBG) | (0<<ACO) | (0<<ACI) | (0<<ACIE) | (0<<ACIC) | (0<<ACIS1) | (0<<ACIS0);
SFIOR=(0<<ACME);

// ADC initialization
// ADC Clock frequency: 125.000 kHz
// ADC Voltage Reference: AREF pin
// ADC Auto Trigger Source: ADC Stopped
// Only the 8 most significant bits of
// the AD conversion result are used
ADMUX=ADC_VREF_TYPE;
ADCSRA=(1<<ADEN) | (0<<ADSC) | (0<<ADATE) | (0<<ADIF) | (0<<ADIE) | (1<<ADPS2) | (1<<ADPS1) | (0<<ADPS0);
SFIOR=(0<<ADTS2) | (0<<ADTS1) | (0<<ADTS0);
// SPI initialization
// SPI disabled
SPCR=(0<<SPIE) | (0<<SPE) | (0<<DORD) | (0<<MSTR) | (0<<CPOL) | (0<<CPHA) | (0<<SPR1) | (0<<SPR0);

// TWI initialization
// TWI disabled
TWCR=(0<<TWEA) | (0<<TWSTA) | (0<<TWSTO) | (0<<TWEN) | (0<<TWIE);

// Bit-Banged I2C Bus initialization
// I2C Port: PORTC
// I2C SDA bit: 1
// I2C SCL bit: 0
// Bit Rate: 100 kHz
// Note: I2C settings are specified in the
// Project|Configure|C Compiler|Libraries|I2C menu.
i2c_init();

// DS1307 Real Time Clock initialization
// Square wave output on pin SQW/OUT: Off
// SQW/OUT pin state: 0
rtc_init(0,0,0);

// Alphanumeric LCD initialization
// Connections are specified in the
// Project|Configure|C Compiler|Libraries|Alphanumeric LCD menu:
// RS - PORTB Bit 1
// RD - PORTB Bit 2
// EN - PORTB Bit 3
// D4 - PORTB Bit 4
// D5 - PORTB Bit 5
// D6 - PORTB Bit 6
// D7 - PORTB Bit 7
// Characters/line: 16
lcd_init(16);
define_char(degreeSymbol, 0);
lcd_clear();


rtc_get_time(&Hour, &Minute, &Second);
rtc_get_date(&Weekday, &Day, &Month, &Year);

if (Year_century == 0) Year_century = 20;

read_eeprom();
       
PORTD.0  = alarm;        

main_loop();
   
}

void main_loop()
{
    while(1)
    {             
       
        rtc_get_time(&Hour, &Minute, &Second);
        rtc_get_date(&Weekday, &Day, &Month, &Year); 
        time_date_functions(); 
        
        switch(PINA & 0x0F)
        {
            case 1:
                if(menu_selector==0)  A_up_sw();
                else up_sw();
                break;   
            case 2:
                if(alarm_selector==0) menu_sw();
                break; 
            case 4:
                if(menu_selector==0)  A_down_sw();
                else down_sw();  
                break; 
            case 8:
                if(menu_selector==0)  A_menu_sw();  
                break;
        }
        
        if ((menu_selector == 0)&&(alarm_selector == 0))
        {          
              Temp = read_adc(7);   
            
            if (Second % 10 < 5)
            {
                sprintf(lcd_buff, "%.4i/%.2i/%.2i ", (Year_century * 100) + Year, Month, Day); 
            }
            else
            {
                m2s( Year, Month, Day, &sYear, &sMonth, &sDay); 
                sYear=sYear+1300;
                sprintf(lcd_buff, "%.4i/%.2i/%.2i ", sYear, sMonth, sDay);
            }
            lcd_gotoxy(0, 0);
            lcd_puts(lcd_buff); 

            switch(Weekday)
            {
                case 1:
                    sprintf(lcd_buff, "SUN"); 
                    break;
                case 2:
                    sprintf(lcd_buff, "MON"); 
                    break;
                case 3:
                    sprintf(lcd_buff, "TUE"); 
                    break;             
                case 4:
                    sprintf(lcd_buff, "WED");   
                    break;            
                case 5:
                    sprintf(lcd_buff, "THU"); 
                    break;             
                case 6:
                    sprintf(lcd_buff, "FRI");     
                    break;        
                case 7:
                    sprintf(lcd_buff, "SAT");  
                    break;
            } 
            lcd_gotoxy(13, 0);        
            lcd_puts(lcd_buff);
            sprintf(lcd_buff, "%.2i:%.2i:%.2i %.1f", Hour, Minute, Second, Temp);   
            lcd_gotoxy(0, 1);
            lcd_puts(lcd_buff);
            lcd_putchar(0); 
            lcd_puts("C  ");
        }
        if (menu_selector > 0)
        {
            showMenu();
        } 
        if (alarm_selector > 0)
        {
            alarmMenu();
        }
        
        if(alarm==1){  
        if((A_Month==sMonth)&&(A_Day==sDay)&&(A_Hour==Hour)&&(A_Minute==Minute)){
        PORTD.1 = 1;
        
        }
        else PORTD.1 = 0;
        }         
        
    delay_ms(500);
    }    
}

void time_date_functions()
{
    if (menu_selector == 0)
    {
        if (Weekday == 0 || Weekday > 7) Weekday = 1; 
        if (Day == 0) Day = 1;
        if ((Day > 31) && (Month == 1 || Month == 3 || Month == 5 || Month == 7 || Month == 8 || Month == 10 || Month == 12))
        {
            Day = 1;
            Month++;
        }
        if ((Day > 30) && (Month == 4 || Month == 6 || Month == 9 || Month == 11))
        {
            Day = 1;
            Month++;
        } 
        if (Day > 28 && Month == 2 && isLeapYear((Year_century * 100) + Year, 1) == 0)
        {
            Day = 1;
            Month++;        
        }    
        if (Month == 0) Month = 1;
        if (Month > 12)
        {
            Month = 1;
            Year++;
        }
        if (Year > 99)
        {
            Year = 0;     
            Year_century++;
        }
        if (Year_century > 99)
        {
            Year = 0;     
            Year_century = 0;
        }        
    }    
}

void up_sw()
{
    switch(menu_selector)
    {
        case 1:
            if (Year_century >= 99) Year_century = 0; else Year_century++; 
            break;
        case 2:
            if (Year >= 99) Year = 0; else Year++;   
            break;
        case 3:
            if (Month >= 12) Month = 1; else Month++; 
            break;
        case 4:
            if ((Day >= 31) && (Month == 1 || Month == 3 || Month == 5 || Month == 7 || Month == 8 || Month == 10 ||Month == 12)) {Day = 1; break;}
            else if ((Day >= 30) && (Month == 4 || Month == 6 || Month == 9 || Month == 11)) {Day = 1; break;}   
            else if (Day >= 29 && Month == 2 && isLeapYear((Year_century * 100) + Year, 1) == 1) {Day = 1; break;}  
            else if (Day >= 28 && Month == 2 && isLeapYear((Year_century * 100) + Year, 1) == 0) {Day = 1; break;} 
            else {Day++; break;}   
        case 5:
            if (Hour >= 23) Hour = 0; else Hour++;  
            break;
        case 6:
            if (Minute >= 59) Minute = 0; else Minute++;  
            break;
        case 7:
            Second = 0; 
            break;
        case 8:
            if (Weekday >= 7) Weekday = 1; else Weekday++; 
            break;  
    }
    delay_ms(500);
}

void menu_sw()
{
    lcd_clear();
    if (menu_selector >= 8) 
    {
        menu_selector = 0; 
        rtc_set_time(Hour, Minute, Second);
        rtc_set_date(Weekday, Day, Month, Year);
    }
    else menu_selector++;
    delay_ms(500);
}

void down_sw()
{
    switch(menu_selector)
    {
        case 1:
            if (Year_century <= 0) Year_century = 99; else Year_century--;     
            break;
        case 2:
            if (Year <= 0) Year = 99; else Year--;     
            break;
        case 3:
            if (Month <= 1) Month = 12; else Month--;  
            break;
        case 4:
            if ((Day <= 1) && (Month == 1 || Month == 3 || Month == 5 || Month == 7 || Month == 8 || Month == 10 ||Month == 12)) {Day = 31; break;} 
            else if ((Day <= 1) && (Month == 4 || Month == 6 || Month == 9 || Month == 11)) {Day = 30; break;} 
            else if (Day <= 1 && Month == 2 && isLeapYear((Year_century * 100) + Year, 1) == 1) {Day = 29; break;} 
            else if (Day <= 1 && Month == 2 && isLeapYear((Year_century * 100) + Year, 1) == 0) {Day = 28; break;}
            else {Day--; break;}   
        case 5:
            if (Hour <= 0) Hour = 23; else Hour--;    
            break;
        case 6:
            if (Minute <= 0) Minute = 59; else Minute--; 
            break;
        case 7:
            Second = 0;    
            break;
        case 8:
            if (Weekday <= 1) Weekday = 7; else Weekday--;    
            break;
    }
    delay_ms(500);
}

int isLeapYear(int _year, int _type)
{
    switch(_type)
    {
        case 1:
            if (_year % 4 == 0) return 1; else return 0; 
            if ((_year % 100 == 0) && (_year % 400 == 0)) return 1; else return 0;    
            break;
        case 2:
            if (_year % 4 == 3) return 1; else return 0;       
            break;
    }
}
 
void showMenu()
{
    switch(menu_selector)
    {
        case 1:
            lcd_gotoxy(0, 0); lcd_puts("Year Century:");     
            sprintf(lcd_buff, "%.2i", Year_century);
            lcd_gotoxy(8, 1); lcd_puts(lcd_buff);
            break;
        case 2:
            lcd_gotoxy(0, 0); lcd_puts("Year:");
            sprintf(lcd_buff, "%.2i", Year);
            lcd_gotoxy(8, 1); lcd_puts(lcd_buff); 
            break;        
        case 3:
            lcd_gotoxy(0, 0); lcd_puts("Month:");
            sprintf(lcd_buff, "%.2i", Month);
            lcd_gotoxy(8, 1); lcd_puts(lcd_buff);
            break;
        case 4:
            lcd_gotoxy(0, 0); lcd_puts("Day:");
            sprintf(lcd_buff, "%.2i", Day);
            lcd_gotoxy(8, 1); lcd_puts(lcd_buff);  
            break;        
        case 5:
            lcd_gotoxy(0, 0); lcd_puts("Hour:");
            sprintf(lcd_buff, "%.2i", Hour);
            lcd_gotoxy(8, 1); lcd_puts(lcd_buff);
            break;        
        case 6:
            lcd_gotoxy(0, 0); lcd_puts("Minute:");
            sprintf(lcd_buff, "%.2i", Minute);
            lcd_gotoxy(8, 1); lcd_puts(lcd_buff); 
            break;         
        case 7:
            lcd_gotoxy(0, 0); lcd_puts("Second:");
            sprintf(lcd_buff, "%.2i", Second);
            lcd_gotoxy(8, 1); lcd_puts(lcd_buff);
            break;          
        case 8:
            lcd_gotoxy(0, 0); lcd_puts("Weekday:");
            lcd_gotoxy(0, 1);
            switch(Weekday)
            {
                case 1:
                    lcd_puts("     Sunday     "); break;
                case 2:
                    lcd_puts("     Monday     "); break;
                case 3:
                    lcd_puts("     Tuesday    "); break;
                case 4:
                    lcd_puts("    Wednesday   "); break;
                case 5:
                    lcd_puts("    Thursday    "); break;
                case 6:
                    lcd_puts("     Friday     "); break;
                case 7:
                    lcd_puts("    Saturday    "); break;
            }  
            break;
    }
}

void define_char(char flash *pc, char char_code)
{
    char i, a;
    a = (char_code << 3) | 0x40;
    for (i = 0; i < 8; i++) lcd_write_byte(a++, *pc++);
}

void A_up_sw()
{
    switch(alarm_selector)
    {
        case 1:
            if(alarm==0)alarm=1;
            else alarm=0;
            break;        
        case 2:   
            A_Year++;
            if (A_Year > 99) A_Year = 0;    
            break;
        case 3:
            A_Month++;
            if (A_Month > 12) A_Month = 1; 
            break;
        case 4:
            A_Day++;
            if (A_Day > 31) A_Day = 1;
            break;  
        case 5:                        
            A_Hour++;
            if (A_Hour > 23) A_Hour = 0;  
            break;
        case 6:                          
            A_Minute++;
            if (A_Minute > 59) A_Minute = 0;  
            break;
    }
    delay_ms(500);
}

void A_down_sw()
{
    switch(alarm_selector)
    {
        case 1:
            if(alarm==0)alarm=1;
            else alarm=0;
            break;
        case 2:
            A_Year--;
            if (A_Year > 99) A_Year = 99;    
            break;
        case 3:             
            A_Month--;
            if (A_Month < 1) A_Month = 12;  
            break;
        case 4:
            A_Day--;
            if (A_Day < 1) A_Day = 31;  
            break;
        case 5:                      
            A_Hour--;
            if (A_Hour > 23) A_Hour = 23;    
            break;
        case 6:                          
            A_Minute--;
            if (A_Minute >59) A_Minute = 59; 
            break;
        
    }
    delay_ms(500);
}

void A_menu_sw()
{
    lcd_clear();
    if (alarm_selector >= 6) 
    {
        alarm_selector = 0;
        E_alarm  = alarm; 
        AE_Year  = A_Year;
        AE_Month = A_Month;
        AE_Day   = A_Day;
        AE_Hour  = A_Hour;
        AE_Minute= A_Minute;
        PORTD.0  = alarm;
    }
    else alarm_selector++;
    delay_ms(500);
}

void alarmMenu()
{
    switch(alarm_selector)
    {   
        case 1:
            if(alarm==1){lcd_gotoxy(0, 0); lcd_puts("ALARM: ON ");}
            else        {lcd_gotoxy(0, 0); lcd_puts("ALARM: OFF");}
            break;         
        case 2:
            if(alarm==0){alarm_selector = 0;PORTD.0  = alarm;break;} 
            lcd_gotoxy(0, 0); lcd_puts("A_Year:");
            sprintf(lcd_buff, "%.2i", A_Year);
            lcd_gotoxy(8, 1); lcd_puts(lcd_buff); 
            break;        
        case 3:
            lcd_gotoxy(0, 0); lcd_puts("A_Month:");
            sprintf(lcd_buff, "%.2i", A_Month);
            lcd_gotoxy(8, 1); lcd_puts(lcd_buff);
            break;
        case 4:
            lcd_gotoxy(0, 0); lcd_puts("A_Day:");
            sprintf(lcd_buff, "%.2i", A_Day);
            lcd_gotoxy(8, 1); lcd_puts(lcd_buff);  
            break;        
        case 5:
            lcd_gotoxy(0, 0); lcd_puts("A_Hour:");
            sprintf(lcd_buff, "%.2i", A_Hour);
            lcd_gotoxy(8, 1); lcd_puts(lcd_buff);
            break;        
        case 6:
            lcd_gotoxy(0, 0); lcd_puts("A_Minute:");
            sprintf(lcd_buff, "%.2i", A_Minute);
            lcd_gotoxy(8, 1); lcd_puts(lcd_buff); 
            break;         
    }
}

void read_eeprom(void){
if(AE_Year<=99)  A_Year  = AE_Year;
else             A_Year  = 3;
if(AE_Month<=12) A_Month = AE_Month;
else             A_Month = 3;
if(AE_Day<=31)   A_Day   = AE_Day;
else             A_Day   = 3;
if(AE_Hour<=23)  A_Hour  = AE_Hour;
else             A_Hour  = 0;
if(AE_Minute<=59)A_Minute= AE_Minute;
else             A_Minute= 0;        
if(E_alarm<=1)   alarm   = E_alarm;
else             alarm   = 0;
}   